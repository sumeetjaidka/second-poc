package com.qa.client;

import java.io.IOException;
import java.util.HashMap;

import org.apache.http.Header;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

public class RestClient {

	//1.Get Method
	
	public void get(String url) throws ClientProtocolException, IOException{
	CloseableHttpClient httpClient =	HttpClients.createDefault();
		HttpGet httpget = new HttpGet(url);//http get request
		CloseableHttpResponse closeableHttpResponse = httpClient.execute(httpget);//hit the get url
		
		//a.Status code
		int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
		System.out.println("Status code---->"+statusCode);
		
		//b.json string
		String responseString = EntityUtils.toString(closeableHttpResponse.getEntity(),"UTF-8");
		
		
		  JSONArray  array=new JSONArray(responseString);
		  
		    for(int i=0;i<array.length();i++)
		    {
		    	
		    	JSONObject  responseJson= (JSONObject)array.get(i);
		    	
		    	
		    	//JSONObject responseJson = new JSONObject(responseString);
				System.out.println("Response JSON from API---->"+responseJson);
				
				//c. All headers
				
				Header[] headersArray= closeableHttpResponse.getAllHeaders();
				
				HashMap<String,String>allHeaders=new HashMap<String,String>();
				
				for(Header header:headersArray){
					
					allHeaders.put(header.getName(), header.getValue());
				}
				System.out.println("Headers Array------>"+allHeaders);	
		    	
		    	
		    	
		    	
		    }
		  
		  
		  
		  
		
//		JSONObject responseJson = new JSONObject(responseString);
//		System.out.println("Response JSON from API---->"+responseJson);
//		
//		//c. All headers
//		
//		Header[] headersArray= closeableHttpResponse.getAllHeaders();
//		
//		HashMap<String,String>allHeaders=new HashMap<String,String>();
//		
//		for(Header header:headersArray){
//			
//			allHeaders.put(header.getName(), header.getValue());
//		}
//		System.out.println("Headers Array------>"+allHeaders);
	}
	
	
	
	
}
